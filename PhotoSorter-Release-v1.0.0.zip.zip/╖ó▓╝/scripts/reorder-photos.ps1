###############################################################################
# Photo reorder tool: brightness-first + color grouping (ASCII only)
###############################################################################
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [int]$Window = 6,
  [ValidateSet('InPlace','Copy')][string]$Mode = 'InPlace',
  [string]$OutDir = '',
  [switch]$DryRun,
  [switch]$IncludeSubdirs,
  [string[]]$Extensions = @('*.jpg','*.jpeg','*.png','*.webp'),
  [int]$BrightSize = 64,
  [int]$HueSize = 96,
  [switch]$NormalizeSubfolders,
  [int]$FolderPad = 2
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Drawing

function Get-Images([string]$dir){
  # -Include requires wildcard in -Path and, for many cases, -Recurse as well.
  $base = Join-Path $dir '*'
  if($IncludeSubdirs){
    return Get-ChildItem -Path $base -File -Include $Extensions -Recurse -ErrorAction SilentlyContinue -Force
  } else {
    return Get-ChildItem -Path $base -File -Include $Extensions -ErrorAction SilentlyContinue -Force
  }
}

function Get-Brightness([string]$path, [int]$size){
  try{
    $img=[System.Drawing.Image]::FromFile($path)
    $thumb=$img.GetThumbnailImage($size,$size,$null,[intptr]::Zero)
    $bmp=[System.Drawing.Bitmap]$thumb
    $sum=0.0
    for($y=0;$y -lt $size;$y++){
      for($x=0;$x -lt $size;$x++){
        $c=$bmp.GetPixel($x,$y)
        $sum += 0.2126*$c.R + 0.7152*$c.G + 0.0722*$c.B
      }
    }
    $img.Dispose(); $thumb.Dispose(); $bmp.Dispose();
    return $sum / ($size*$size)
  }catch{ return [double]::NaN }
}

function Get-DominantGroup([string]$path, [int]$size){
  # Groups: 1=Blue/Cyan(140-260), 2=Yellow(25-75), 3=Red(0-30 or 330-360), 4=Other
  try{
    $img=[System.Drawing.Image]::FromFile($path)
    $thumb=$img.GetThumbnailImage($size,$size,$null,[intptr]::Zero)
    $bmp=[System.Drawing.Bitmap]$thumb
    $sumB=0.0; $sumY=0.0; $sumR=0.0; $sum=0.0
    for($y=0;$y -lt $size;$y++){
      for($x=0;$x -lt $size;$x++){
        $c=$bmp.GetPixel($x,$y)
        $r=[double]$c.R; $g=[double]$c.G; $b=[double]$c.B
        $mx=[Math]::Max($r,[Math]::Max($g,$b)); $mn=[Math]::Min($r,[Math]::Min($g,$b)); $dl=$mx-$mn
        if($mx -le 0){ continue }
        $s = if($mx -eq 0){ 0.0 } else { $dl/$mx }
        $h=0.0
        if($dl -eq 0){ $h=0 }
        elseif($mx -eq $r){ $h = 60.0 * ((($g-$b)/$dl) % 6.0) }
        elseif($mx -eq $g){ $h = 60.0 * ((($b-$r)/$dl) + 2.0) }
        else { $h = 60.0 * ((($r-$g)/$dl) + 4.0) }
        if($h -lt 0){ $h += 360.0 }
        $w=[Math]::Max(0.05,$s)
        $sum += $w
        if(($h -ge 140 -and $h -le 260)){ $sumB += $w }
        elseif(($h -ge 25 -and $h -le 75)){ $sumY += $w }
        elseif(($h -ge 0 -and $h -le 30) -or ($h -ge 330 -and $h -lt 360)){ $sumR += $w }
      }
    }
    $img.Dispose(); $thumb.Dispose(); $bmp.Dispose();
    if($sum -le 0){ return 4 }
    $rB=$sumB/$sum; $rY=$sumY/$sum; $rR=$sumR/$sum
    if(($rB -ge $rY) -and ($rB -ge $rR)){ return 1 }
    if(($rY -ge $rB) -and ($rY -ge $rR)){ return 2 }
    return 3
  }catch{ return 4 }
}

function Safe-Rename([string]$src,[string]$dst){
  $ok=$false
  for($t=0;$t -lt 6 -and -not $ok;$t++){
    try{ Rename-Item -LiteralPath $src -NewName $dst -Force; $ok=$true } catch { Start-Sleep -Milliseconds 250 }
  }
  if(-not $ok){ try{ Copy-Item -LiteralPath $src -Destination $dst -Force; Remove-Item -LiteralPath $src -Force; $ok=$true } catch { $ok=$false } }
  return $ok
}

function Normalize-ChildFolders([string]$basePath, [int]$pad){
  $dirs = Get-ChildItem -LiteralPath $basePath -Directory -ErrorAction SilentlyContinue
  if(!$dirs){ return }
  $tmpNames=@(); $i=1
  foreach($d in $dirs){
    $tmp = Join-Path $basePath ("__nf_tmp_" + $i.ToString('D'+[Math]::Max(2,$pad)))
    if(Test-Path -LiteralPath $tmp){ Remove-Item -LiteralPath $tmp -Recurse -Force }
    Rename-Item -LiteralPath $d.FullName -NewName $tmp -Force
    $tmpNames += $tmp; $i++
  }
  $i=1
  foreach($t in $tmpNames){
    $final = Join-Path $basePath ($i.ToString('D'+[Math]::Max(2,$pad)))
    if(Test-Path -LiteralPath $final){ Remove-Item -LiteralPath $final -Recurse -Force }
    Rename-Item -LiteralPath $t -NewName $final -Force
    $i++
  }
}

if(!(Test-Path -LiteralPath $Path)){ throw "Path not found: $Path" }
if($NormalizeSubfolders){ Normalize-ChildFolders -basePath $Path -pad $FolderPad }

$files = Get-Images $Path
if(!$files){ throw "No images found: $Path" }

$items=@()
foreach($f in $files){
  $b = Get-Brightness $f.FullName $BrightSize
  if([double]::IsNaN($b)){ continue }
  $g = Get-DominantGroup $f.FullName $HueSize
  $items += [pscustomobject]@{ File=$f; Bright=$b; Group=$g }
}

if($items.Count -eq 0){ throw "Brightness calculation failed for all images (or unreadable): $Path" }

$items = $items | Sort-Object Bright

$ordered=@()
for($i=0; $i -lt $items.Count; $i += $Window){
  $end=[Math]::Min($i+$Window-1, $items.Count-1)
  $chunk = @(); for($j=$i; $j -le $end; $j++){ $chunk += $items[$j] }
  $ordered += ($chunk | Sort-Object Group, Bright)
}

if($DryRun){
  $idx=1
  $ordered | ForEach-Object { Write-Host ("{0,4}. {1}  Bright={2,6:N1}  Group={3}" -f $idx, $_.File.Name, $_.Bright, $_.Group); $idx++ }
  return
}

switch($Mode){
  'Copy' {
    if([string]::IsNullOrWhiteSpace($OutDir)){ throw "OutDir cannot be empty (Copy mode)" }
    if(Test-Path -LiteralPath $OutDir){ Remove-Item -LiteralPath $OutDir -Recurse -Force }
    New-Item -ItemType Directory -Path $OutDir | Out-Null
    $n=1; foreach($it in $ordered){ $ext=$it.File.Extension; $dest = Join-Path $OutDir ($n.ToString() + $ext); Copy-Item -LiteralPath $it.File.FullName -Destination $dest -Force; $n++ }
  }
  'InPlace' {
    $pad = [Math]::Max(2, ([Math]::Ceiling([Math]::Log10([double]($ordered.Count+1)))) )
    $stage=@(); $n=1
    foreach($it in $ordered){ $ext=$it.File.Extension; $tmp = "__recolor_tmp_" + $n.ToString('D'+$pad) + $ext; $tmpFull = Join-Path $Path $tmp; if(Safe-Rename $it.File.FullName $tmpFull){ $stage += $tmpFull; $n++ } }
    $n=1; foreach($tmp in $stage){ $ext=[System.IO.Path]::GetExtension($tmp); $finalFull = Join-Path $Path ($n.ToString() + $ext); if(Test-Path -LiteralPath $finalFull){ Remove-Item -LiteralPath $finalFull -Force } if(Safe-Rename $tmp $finalFull){ $n++ } }
    Get-ChildItem -LiteralPath $Path -File -Filter '__recolor_tmp_*' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
  }
}

Write-Host ("Done: {0} images {1}." -f $ordered.Count, $(if($Mode -eq 'Copy'){"copied to $OutDir"} else {"renamed in-place"}))
