###############################################################################
# Photo reorder tool: orientation -> color -> brightness (ASCII only)
###############################################################################
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [ValidateSet('InPlace','Copy')][string]$Mode = 'InPlace',
  [string]$OutDir = '',
  [switch]$DryRun,
  [switch]$IncludeSubdirs,
  [string[]]$Extensions = @('*.jpg','*.jpeg','*.png','*.webp'),
  [int]$BrightSize = 64,
  [int]$HueSize = 96,
  [double]$SatMin = 0.12
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Drawing

function Get-Images([string]$dir){
  $base = Join-Path $dir '*'
  if($IncludeSubdirs){
    return Get-ChildItem -Path $base -File -Include $Extensions -Recurse -ErrorAction SilentlyContinue -Force
  } else {
    return Get-ChildItem -Path $base -File -Include $Extensions -ErrorAction SilentlyContinue -Force
  }
}

function Get-Orientation([string]$path){
  try{
    $img=[System.Drawing.Image]::FromFile($path)
    $w=$img.Width; $h=$img.Height
    $img.Dispose()
    if($w -gt $h){ return @{ Code='L'; Group=1 } } # Landscape (horizontal)
    elseif($w -lt $h){ return @{ Code='P'; Group=0 } } # Portrait (vertical)
    else { return @{ Code='L'; Group=1 } } # Square -> treat as landscape
  }catch{ return @{ Code='L'; Group=1 } }
}

function Get-Brightness([string]$path, [int]$size){
  try{
    $img=[System.Drawing.Image]::FromFile($path)
    $thumb=$img.GetThumbnailImage($size,$size,$null,[intptr]::Zero)
    $bmp=[System.Drawing.Bitmap]$thumb
    $sum=0.0
    for($y=0;$y -lt $size;$y++){
      for($x=0;$x -lt $size;$x++){
        $c=$bmp.GetPixel($x,$y)
        $sum += 0.2126*$c.R + 0.7152*$c.G + 0.0722*$c.B
      }
    }
    $img.Dispose(); $thumb.Dispose(); $bmp.Dispose();
    return $sum / ($size*$size)
  }catch{ return [double]::NaN }
}

function Get-DominantGroup([string]$path, [int]$size){
  # Finer hue groups (HSV hue in degrees):
  # 1=Red ([-22.5,22.5))
  # 2=Orange ([22.5,67.5))
  # 3=Yellow ([67.5,112.5))
  # 4=Green ([112.5,157.5))
  # 5=Cyan ([157.5,202.5))
  # 6=Blue ([202.5,247.5))
  # 7=Purple ([247.5,292.5))
  # 8=Magenta ([292.5,337.5))
  # 9=Neutral/Other (low saturation or undefined)
  try{
    $img=[System.Drawing.Image]::FromFile($path)
    $thumb=$img.GetThumbnailImage($size,$size,$null,[intptr]::Zero)
    $bmp=[System.Drawing.Bitmap]$thumb
    $acc = @(0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0)
    $sum=0.0
    for($y=0;$y -lt $size;$y++){
      for($x=0;$x -lt $size;$x++){
        $c=$bmp.GetPixel($x,$y)
        $r=[double]$c.R; $g=[double]$c.G; $b=[double]$c.B
        $mx=[Math]::Max($r,[Math]::Max($g,$b)); $mn=[Math]::Min($r,[Math]::Min($g,$b)); $dl=$mx-$mn
        if($mx -le 0){ continue }
        $s = if($mx -eq 0){ 0.0 } else { $dl/$mx }
        if($s -le $SatMin){ continue }
        $h=0.0
        if($dl -eq 0){ $h=0 }
        elseif($mx -eq $r){ $h = 60.0 * ((($g-$b)/$dl) % 6.0) }
        elseif($mx -eq $g){ $h = 60.0 * ((($b-$r)/$dl) + 2.0) }
        else { $h = 60.0 * ((($r-$g)/$dl) + 4.0) }
        if($h -lt 0){ $h += 360.0 }
        $w = $s - $SatMin
        $sum += $w
        # Map hue to one of the 8 bins with 45-degree width.
        if(($h -ge 337.5 -and $h -lt 360) -or ($h -ge 0 -and $h -lt 22.5)){
          $acc[0] += $w  # Red
        } elseif($h -ge 22.5 -and $h -lt 67.5){
          $acc[1] += $w  # Orange
        } elseif($h -ge 67.5 -and $h -lt 112.5){
          $acc[2] += $w  # Yellow
        } elseif($h -ge 112.5 -and $h -lt 157.5){
          $acc[3] += $w  # Green
        } elseif($h -ge 157.5 -and $h -lt 202.5){
          $acc[4] += $w  # Cyan
        } elseif($h -ge 202.5 -and $h -lt 247.5){
          $acc[5] += $w  # Blue
        } elseif($h -ge 247.5 -and $h -lt 292.5){
          $acc[6] += $w  # Purple
        } elseif($h -ge 292.5 -and $h -lt 337.5){
          $acc[7] += $w  # Magenta
        }
      }
    }
    $img.Dispose(); $thumb.Dispose(); $bmp.Dispose();
    if($sum -le 0){ return 9 }
    # Pick the dominant bin; fallback to Neutral(9) if all zero
    $maxVal = -1.0; $maxIdx = -1
    for($i=0;$i -lt 8;$i++){
      if($acc[$i] -gt $maxVal){ $maxVal = $acc[$i]; $maxIdx = $i }
    }
    if($maxIdx -lt 0){ return 9 } else { return ($maxIdx + 1) }
  }catch{ return 9 }
}

function Safe-Rename([string]$src,[string]$dst){
  $ok=$false
  for($t=0;$t -lt 6 -and -not $ok;$t++){
    try{ Rename-Item -LiteralPath $src -NewName $dst -Force; $ok=$true } catch { Start-Sleep -Milliseconds 250 }
  }
  if(-not $ok){ try{ Copy-Item -LiteralPath $src -Destination $dst -Force; Remove-Item -LiteralPath $src -Force; $ok=$true } catch { $ok=$false } }
  return $ok
}

if(!(Test-Path -LiteralPath $Path)){ throw "Path not found: $Path" }

$files = Get-Images $Path
if(!$files){ throw "No images found: $Path" }

$items=@()
foreach($f in $files){
  $b = Get-Brightness $f.FullName $BrightSize
  if([double]::IsNaN($b)){ continue }
  $g = Get-DominantGroup $f.FullName $HueSize
  $o = Get-Orientation $f.FullName
  $items += [pscustomobject]@{ File=$f; Bright=$b; Group=$g; OriGroup=$o.Group; OriCode=$o.Code }
}

if($items.Count -eq 0){ throw "Feature extraction failed for all images (or unreadable): $Path" }

# Sort by orientation (P first), then color group, then brightness
$ordered = $items | Sort-Object OriGroup, Group, Bright

if($DryRun){
  $idx=1
  $groupNames = @{1='Red';2='Orange';3='Yellow';4='Green';5='Cyan';6='Blue';7='Purple';8='Magenta';9='Neutral'}
  $ordered | ForEach-Object {
    $gname = $groupNames[[int]$_.Group]
    Write-Host ("{0,4}. [{1}] {2}  Bright={3,6:N1}  Group={4}({5})" -f $idx, $_.OriCode, $_.File.Name, $_.Bright, $_.Group, $gname); $idx++
  }
  return
}

switch($Mode){
  'Copy' {
    if([string]::IsNullOrWhiteSpace($OutDir)){ throw "OutDir cannot be empty (Copy mode)" }
    if(Test-Path -LiteralPath $OutDir){ Remove-Item -LiteralPath $OutDir -Recurse -Force }
    New-Item -ItemType Directory -Path $OutDir | Out-Null
    $p=1; $l=1
    foreach($it in $ordered){
      $ext=$it.File.Extension
      if($it.OriCode -eq 'P'){
        $dest = Join-Path $OutDir (('P' + $p.ToString('D3')) + $ext)
        Copy-Item -LiteralPath $it.File.FullName -Destination $dest -Force
        $p++
      } else {
        $dest = Join-Path $OutDir (('L' + $l.ToString('D3')) + $ext)
        Copy-Item -LiteralPath $it.File.FullName -Destination $dest -Force
        $l++
      }
    }
  }
  'InPlace' {
    # Stage with temp names to avoid collisions, then finalize with P/L prefixes and per-group counters
    $stage=@(); $n=1
    foreach($it in $ordered){
      $ext=$it.File.Extension
      $tmp = "__recolor_cf_tmp_" + $n.ToString('D4') + $ext
      $tmpFull = Join-Path $Path $tmp
      if(Safe-Rename $it.File.FullName $tmpFull){ $stage += @{ Tmp=$tmpFull; Ori=$it.OriCode }; $n++ }
    }
    $p=1; $l=1
    foreach($s in $stage){
      $ext=[System.IO.Path]::GetExtension($s.Tmp)
      if($s.Ori -eq 'P'){
        $finalFull = Join-Path $Path (('P' + $p.ToString('D3')) + $ext)
        if(Test-Path -LiteralPath $finalFull){ Remove-Item -LiteralPath $finalFull -Force }
        if(Safe-Rename $s.Tmp $finalFull){ $p++ }
      } else {
        $finalFull = Join-Path $Path (('L' + $l.ToString('D3')) + $ext)
        if(Test-Path -LiteralPath $finalFull){ Remove-Item -LiteralPath $finalFull -Force }
        if(Safe-Rename $s.Tmp $finalFull){ $l++ }
      }
    }
    Get-ChildItem -LiteralPath $Path -File -Filter '__recolor_cf_tmp_*' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
  }
}

Write-Host ("Done: {0} images {1}." -f $ordered.Count, $(if($Mode -eq 'Copy'){"copied to $OutDir"} else {"renamed in-place"}))
