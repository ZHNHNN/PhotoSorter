<#
将指定目录下的“子文件夹”规范为 01, 02, ... 的数字命名（两阶段改名，避免冲突）。
用法：
  .\normalize-folders.ps1 -Path "D:\photos" -Pad 2
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory=$true)][string]$Path,
  [int]$Pad = 2
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if(!(Test-Path -LiteralPath $Path)){ throw "Path not found: $Path" }
$dirs = Get-ChildItem -LiteralPath $Path -Directory -ErrorAction SilentlyContinue
if(!$dirs){ Write-Host 'No subfolders'; return }

$tmpNames=@(); $i=1
foreach($d in $dirs){
  $tmp = Join-Path $Path ("__nf_tmp_" + $i.ToString('D'+[Math]::Max(2,$Pad)))
  if(Test-Path -LiteralPath $tmp){ Remove-Item -LiteralPath $tmp -Recurse -Force }
  Rename-Item -LiteralPath $d.FullName -NewName $tmp -Force
  $tmpNames += $tmp; $i++
}

$i=1
foreach($t in $tmpNames){
  $final = Join-Path $Path ($i.ToString('D'+[Math]::Max(2,$Pad)))
  if(Test-Path -LiteralPath $final){ Remove-Item -LiteralPath $final -Recurse -Force }
  Rename-Item -LiteralPath $t -NewName $final -Force
  $i++
}

Write-Host 'Subfolders normalized (numeric).'
